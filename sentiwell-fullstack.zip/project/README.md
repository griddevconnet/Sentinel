<p align="center">
  <img src="docs/brand/logo-lockup.svg" alt="Sentiwell" width="360" />
</p>

<p align="center">
  <a href="https://github.com/OWNER/REPO/actions/workflows/ci.yml"><img src="https://github.com/OWNER/REPO/actions/workflows/ci.yml/badge.svg" alt="CI status" /></a>
  <a href="./LICENSE"><img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="MIT license" /></a>
  <a href="https://vercel.com/new/clone?repo-url=https://github.com/OWNER/REPO&root-directory=frontend&env=VITE_API_BASE_URL&project-name=sentiwell&repository-name=sentiwell"><img src="https://vercel.com/button" alt="Deploy with Vercel" /></a>
  <a href="https://render.com/deploy?repo=https://github.com/OWNER/REPO"><img src="https://render.com/images/deploy-to-render-button.svg" alt="Deploy to Render" /></a>
</p>

> Replace `OWNER/REPO` above with your actual GitHub path once you've pushed this repo —
> see "Push to GitHub" below.

# Sentiwell, Community Health Reporting and Triage

Full stack application: Node.js/Express/TypeScript/PostgreSQL+PostGIS backend,
React (JavaScript, Vite) frontend. Blue and white glass design throughout.

```
backend/     API, database migrations, cron jobs        (see backend/README.md)
frontend/    React app, connects to the API via one env var  (see frontend/README.md)
```

## Run the whole stack locally

**1. Start the backend and its database**

```bash
cd backend
cp .env.example .env
docker compose up --build -d
docker compose exec api npm run migrate:latest
docker compose exec api npm run seed:run
```

The API is now live at `http://localhost:4000`. Confirm with:

```bash
curl http://localhost:4000/health
```

**2. Start the frontend**

```bash
cd frontend
cp .env.example .env    # VITE_API_BASE_URL already points at localhost:4000/api/v1
npm install
npm run dev
```

Open `http://localhost:5173`.

**3. Sign in as a health worker**

Use one of the seeded demo accounts (see `backend/README.md`), for example:

```
Email:    admin@sentiwell.local
Password: ChangeMe123!
```

Change these credentials before any real deployment.

## What each side owns

- **Backend**: severity scoring, SLA policies and monitoring, the triage state
  machine and audit trail, PostGIS based incident clustering, multilingual
  notifications, report attachments (photo/PDF evidence upload and retrieval),
  auth. Fully documented in `backend/README.md`, including the full endpoint table.
- **Frontend**: the public report and status flows (no login required, installable
  as an offline-capable PWA, with English/French UI), and the health worker triage
  dashboard, report detail, and incidents views (behind sign in). Fully documented
  in `frontend/README.md`, including the design system.

## Deploying

This repo is set up to deploy as two independent services — a common, sensible split for a
Vite/React frontend and a Dockerized API — with config already checked in for both:

**Backend → Render** (`render.yaml`, a Render Blueprint)

1. Push this repo to GitHub (see "Push to GitHub" below).
2. In the Render dashboard: **New → Blueprint**, point it at your repo. Render reads
   `render.yaml` and provisions a Docker web service (`backend/Dockerfile`) plus a managed
   Postgres database with PostGIS, runs migrations automatically on every deploy
   (`preDeployCommand`), and mounts a persistent disk for uploaded report attachments.
3. Render generates `JWT_SECRET` and wires up `DATABASE_URL` for you. After the first
   deploy, set `CORS_ORIGIN` (left blank in the blueprint) to your Vercel URL from the next step.
4. Note the resulting API URL, e.g. `https://sentiwell-api.onrender.com`.

**Frontend → Vercel** (`frontend/vercel.json`)

1. In the Vercel dashboard: **Add New → Project**, import the same repo, and set the
   project's root directory to `frontend` (the "Deploy with Vercel" button above does this
   for you).
2. Set the `VITE_API_BASE_URL` environment variable to your Render API URL plus `/api/v1`,
   e.g. `https://sentiwell-api.onrender.com/api/v1`.
3. Deploy. `vercel.json` already has the SPA rewrite rule the client-side router needs, so
   refreshing on `/report`, `/dashboard`, etc. won't 404.

**Running it yourself instead** — both sides just read plain environment variables, so you
can build and host them anywhere:

```bash
cd backend && npm run build && npm start
cd frontend && npm run build   # serve the resulting dist/ folder as static files
```

## Push to GitHub

This project isn't tied to any particular GitHub account — push it to your own:

```bash
# from the repo root (this folder already has one git commit — see below)
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git branch -M main
git push -u origin main
```

Then update the badge/button URLs at the top of this README (`OWNER/REPO`) to match, so the
CI badge and the Vercel/Render deploy buttons point at your repo instead of the placeholder.
