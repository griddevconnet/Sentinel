import { priorityLabel, statusLabel, priorityBadgeClass, statusBadgeClass } from "../utils/constants";
import { useLanguage } from "../i18n/LanguageContext";

export function PriorityBadge({ priority }) {
  const { t } = useLanguage();
  return (
    <span className={priorityBadgeClass(priority)}>
      <span className="badge-dot" />
      {priorityLabel(t, priority)}
    </span>
  );
}

export function StatusBadge({ status }) {
  const { t } = useLanguage();
  return (
    <span className={statusBadgeClass(status)}>
      <span className="badge-dot" />
      {statusLabel(t, status)}
    </span>
  );
}
