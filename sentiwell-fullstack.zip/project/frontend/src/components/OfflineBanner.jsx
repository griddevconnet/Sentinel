import { useCallback, useEffect, useState } from "react";
import { useLanguage } from "../i18n/LanguageContext";
import { reportsApi } from "../api/reports";
import { flushQueuedReports, queuedReportCount } from "../utils/offlineQueue";

export default function OfflineBanner() {
  const { t } = useLanguage();
  const [isOnline, setIsOnline] = useState(typeof navigator === "undefined" ? true : navigator.onLine);
  const [pending, setPending] = useState(0);
  const [syncMessage, setSyncMessage] = useState("");
  const [isSyncing, setIsSyncing] = useState(false);

  const refreshPending = useCallback(() => setPending(queuedReportCount()), []);

  const sync = useCallback(async () => {
    if (!navigator.onLine || queuedReportCount() === 0) return;
    setIsSyncing(true);
    try {
      const { syncedCount } = await flushQueuedReports((payload) => reportsApi.submit(payload));
      if (syncedCount > 0) {
        setSyncMessage(syncedCount === 1 ? t("offline.syncedOne") : t("offline.syncedMany", { count: syncedCount }));
        setTimeout(() => setSyncMessage(""), 6000);
      }
    } finally {
      setIsSyncing(false);
      refreshPending();
    }
  }, [refreshPending, t]);

  useEffect(() => {
    refreshPending();
    const handleOnline = () => {
      setIsOnline(true);
      sync();
    };
    const handleOffline = () => setIsOnline(false);
    const handleQueueChanged = (event) => setPending(event.detail?.count ?? queuedReportCount());

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    window.addEventListener("sentiwell:queue-changed", handleQueueChanged);

    if (navigator.onLine) sync();

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
      window.removeEventListener("sentiwell:queue-changed", handleQueueChanged);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (isOnline && pending === 0 && !syncMessage) return null;

  return (
    <div className={`offline-banner ${isOnline ? "offline-banner-online" : "offline-banner-offline"}`} role="status">
      {!isOnline && <span>{t("offline.offline")}</span>}
      {isOnline && isSyncing && <span>{t("offline.syncing")}</span>}
      {isOnline && !isSyncing && pending > 0 && (
        <span>{pending === 1 ? t("offline.pendingOne") : t("offline.pendingMany", { count: pending })}</span>
      )}
      {isOnline && !isSyncing && pending === 0 && syncMessage && <span>{syncMessage}</span>}
    </div>
  );
}
