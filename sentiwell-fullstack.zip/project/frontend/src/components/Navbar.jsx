import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useLanguage } from "../i18n/LanguageContext";
import { initials } from "../utils/formatters";
import { LOCALES } from "../i18n/translations";

export default function Navbar() {
  const { isAuthenticated, worker, logout } = useAuth();
  const { language, setLanguage, t } = useLanguage();
  const location = useLocation();
  const navigate = useNavigate();

  const isActive = (path) => location.pathname === path;

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <header className="navbar-wrap">
      <nav className="navbar glass-strong">
        <Link to="/" className="navbar-brand">
          <span className="navbar-brand-mark" aria-hidden="true">
            <svg viewBox="0 0 100 100" width="20" height="20" fill="none">
              <path
                d="M8 50 H26 L33 30 L45 74 L54 26 L63 50 H92"
                stroke="currentColor"
                strokeWidth="9"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </span>
          <span>Sentiwell</span>
        </Link>

        <div className="navbar-links">
          <Link to="/report" className={isActive("/report") ? "navbar-link active" : "navbar-link"}>
            {t("nav.reportConcern")}
          </Link>
          <Link to="/track" className={isActive("/track") ? "navbar-link active" : "navbar-link"}>
            {t("nav.trackReport")}
          </Link>
          {isAuthenticated && (
            <>
              <Link to="/dashboard" className={isActive("/dashboard") ? "navbar-link active" : "navbar-link"}>
                {t("nav.triageQueue")}
              </Link>
              <Link to="/incidents" className={isActive("/incidents") ? "navbar-link active" : "navbar-link"}>
                {t("nav.incidents")}
              </Link>
            </>
          )}
        </div>

        <div className="navbar-actions">
          <label className="navbar-lang-switch" aria-label="Language / Langue">
            <select value={language} onChange={(e) => setLanguage(e.target.value)}>
              {Object.keys(LOCALES).map((code) => (
                <option key={code} value={code}>
                  {code.toUpperCase()}
                </option>
              ))}
            </select>
          </label>

          {isAuthenticated ? (
            <div className="navbar-user">
              <span className="navbar-avatar">{initials(worker?.full_name)}</span>
              <div className="navbar-user-meta">
                <strong>{worker?.full_name}</strong>
                <span>{worker?.role?.replace(/_/g, " ")}</span>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={handleLogout}>
                {t("nav.signOut")}
              </button>
            </div>
          ) : (
            <Link to="/login" className="btn btn-secondary btn-sm">
              {t("nav.signIn")}
            </Link>
          )}
        </div>
      </nav>
    </header>
  );
}
