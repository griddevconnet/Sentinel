import { useState } from "react";
import { useNavigate } from "react-router-dom";
import GlassCard from "../components/GlassCard";
import Button from "../components/Button";
import { ErrorAlert } from "../components/Feedback";
import { useAuth } from "../context/AuthContext";
import { ApiError } from "../api/client";
import { useLanguage } from "../i18n/LanguageContext";

export default function Login() {
  const { t } = useLanguage();
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setIsSubmitting(true);
    try {
      await login(email.trim(), password);
      navigate("/dashboard");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : t("login.errorGeneric"));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="page-shell" style={{ maxWidth: 440, margin: "0 auto" }}>
      <div className="page-header" style={{ padding: "60px 0 24px", display: "block", textAlign: "center" }}>
        <h1>{t("login.heading")}</h1>
        <p style={{ margin: "6px auto 0" }}>{t("login.subheading")}</p>
      </div>

      <GlassCard>
        <form onSubmit={handleSubmit}>
          <div className="field">
            <label className="field-label" htmlFor="email">
              {t("login.email")}
            </label>
            <input
              id="email"
              type="email"
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="field">
            <label className="field-label" htmlFor="password">
              {t("login.password")}
            </label>
            <input
              id="password"
              type="password"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <ErrorAlert message={error} />

          <Button type="submit" block loading={isSubmitting} style={{ marginTop: 6 }}>
            {t("login.signIn")}
          </Button>
        </form>
      </GlassCard>
    </div>
  );
}
