import { useState } from "react";
import { Link } from "react-router-dom";
import GlassCard from "../components/GlassCard";
import Button from "../components/Button";
import { ErrorAlert } from "../components/Feedback";
import { reportsApi } from "../api/reports";
import { ApiError } from "../api/client";
import { useLanguage } from "../i18n/LanguageContext";
import { queueReport, isNetworkError } from "../utils/offlineQueue";
import {
  LANGUAGE_OPTIONS,
  SYMPTOM_CODES,
  categoryLabel,
  categoryDescriptionText,
  symptomLabel,
} from "../utils/constants";

const CATEGORIES = ["individual_symptom", "suspected_outbreak", "environmental_hazard", "other"];
const MAX_ATTACHMENTS = 3;
const ALLOWED_ATTACHMENT_TYPES = ["image/jpeg", "image/png", "image/webp", "application/pdf"];

const initialForm = {
  category: "individual_symptom",
  description: "",
  symptoms: [],
  affectedCount: 1,
  addressText: "",
  isAnonymous: false,
  reporterContact: "",
  reporterLanguage: "en",
};

export default function ReportForm() {
  const { t } = useLanguage();
  const [form, setForm] = useState(initialForm);
  const [location, setLocation] = useState(null);
  const [locationStatus, setLocationStatus] = useState("idle");
  const [attachments, setAttachments] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [submittedReport, setSubmittedReport] = useState(null);
  const [wasQueuedOffline, setWasQueuedOffline] = useState(false);
  const [attachmentWarning, setAttachmentWarning] = useState("");

  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const toggleSymptom = (value) => {
    setForm((prev) => ({
      ...prev,
      symptoms: prev.symptoms.includes(value)
        ? prev.symptoms.filter((s) => s !== value)
        : [...prev.symptoms, value],
    }));
  };

  const captureLocation = () => {
    if (!navigator.geolocation) {
      setLocationStatus("unsupported");
      return;
    }
    setLocationStatus("locating");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({ latitude: position.coords.latitude, longitude: position.coords.longitude });
        setLocationStatus("captured");
      },
      () => setLocationStatus("denied"),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleFilePick = (event) => {
    const picked = Array.from(event.target.files || []).filter((file) =>
      ALLOWED_ATTACHMENT_TYPES.includes(file.type)
    );
    setAttachments((prev) => [...prev, ...picked].slice(0, MAX_ATTACHMENTS));
    event.target.value = "";
  };

  const removeAttachment = (index) => {
    setAttachments((prev) => prev.filter((_, i) => i !== index));
  };

  const buildPayload = () => {
    const payload = {
      isAnonymous: form.isAnonymous,
      reporterLanguage: form.reporterLanguage,
      category: form.category,
      description: form.description.trim(),
      symptoms: form.symptoms,
      affectedCount: Number(form.affectedCount) || 1,
      addressText: form.addressText.trim() || undefined,
      location: location || undefined,
    };
    if (!form.isAnonymous && form.reporterContact.trim()) {
      payload.reporterContact = form.reporterContact.trim();
    }
    return payload;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setAttachmentWarning("");

    if (form.description.trim().length < 5) {
      setError(t("reportForm.errorShort"));
      return;
    }

    const payload = buildPayload();
    setIsSubmitting(true);

    // Offline (or the browser already knows there's no connection): save on-device and
    // sync automatically once connectivity returns, instead of failing the submission.
    if (typeof navigator !== "undefined" && !navigator.onLine) {
      queueReport(payload);
      setWasQueuedOffline(true);
      setSubmittedReport({ report_token: null });
      setIsSubmitting(false);
      return;
    }

    try {
      const res = await reportsApi.submit(payload);
      setSubmittedReport(res.data);

      if (attachments.length > 0) {
        try {
          await reportsApi.uploadAttachments(res.data.id, attachments);
        } catch {
          setAttachmentWarning(t("reportForm.attachmentsUploadFailed"));
        }
      }
    } catch (err) {
      if (isNetworkError(err)) {
        queueReport(payload);
        setWasQueuedOffline(true);
        setSubmittedReport({ report_token: null });
      } else {
        setError(err instanceof ApiError ? err.message : t("reportForm.errorGeneric"));
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submittedReport) {
    return (
      <div className="page-shell" style={{ maxWidth: 620, margin: "0 auto" }}>
        <GlassCard style={{ marginTop: 48, textAlign: "center" }}>
          <div className="option-icon" style={{ margin: "0 auto 18px" }} aria-hidden="true">
            {wasQueuedOffline ? "\u21bb" : "\u2713"}
          </div>
          <h2 style={{ marginBottom: 10 }}>
            {wasQueuedOffline ? t("reportForm.offlineHeading") : t("reportForm.successHeading")}
          </h2>
          <p style={{ color: "#5c6b85", marginBottom: 26 }}>
            {wasQueuedOffline ? t("reportForm.offlineBody") : t("reportForm.successBody")}
          </p>

          {!wasQueuedOffline && (
            <div
              className="glass"
              style={{
                padding: "18px 24px",
                fontFamily: "var(--font-display)",
                fontSize: "1.6rem",
                fontWeight: 700,
                letterSpacing: "0.12em",
                color: "var(--blue-700)",
                marginBottom: 26,
              }}
            >
              {submittedReport.report_token}
            </div>
          )}

          {attachmentWarning && <ErrorAlert message={attachmentWarning} />}

          <div className="hero-actions">
            {!wasQueuedOffline && (
              <Link to={`/track?token=${submittedReport.report_token}`} className="btn btn-primary">
                {t("reportForm.trackButton")}
              </Link>
            )}
            <Link to="/" className="btn btn-secondary">
              {t("reportForm.homeButton")}
            </Link>
          </div>
        </GlassCard>
      </div>
    );
  }

  return (
    <div className="page-shell">
      <div className="page-header">
        <div>
          <h1>{t("reportForm.heading")}</h1>
          <p>{t("reportForm.subheading")}</p>
        </div>
      </div>

      {typeof navigator !== "undefined" && !navigator.onLine && (
        <div className="alert alert-info" style={{ marginBottom: 18 }}>
          <span aria-hidden="true">{"\u21bb"}</span>
          <span>{t("reportForm.offlineWarning")}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="form-layout">
        <GlassCard>
          <div className="field">
            <span className="field-label">{t("reportForm.categoryQuestion")}</span>
            <div className="chip-group">
              {CATEGORIES.map((value) => (
                <button
                  key={value}
                  type="button"
                  className={`chip ${form.category === value ? "active" : ""}`}
                  onClick={() => update("category", value)}
                >
                  {categoryLabel(t, value)}
                </button>
              ))}
            </div>
            <span className="field-hint">{categoryDescriptionText(t, form.category)}</span>
          </div>

          <div className="field">
            <label className="field-label" htmlFor="description">
              {t("reportForm.descriptionLabel")}
            </label>
            <textarea
              id="description"
              className="textarea"
              placeholder={t("reportForm.descriptionPlaceholder")}
              value={form.description}
              onChange={(e) => update("description", e.target.value)}
              required
            />
          </div>

          <div className="field">
            <span className="field-label">{t("reportForm.symptomsLabel")}</span>
            <div className="chip-group">
              {SYMPTOM_CODES.map((code) => (
                <button
                  key={code}
                  type="button"
                  className={`chip ${form.symptoms.includes(code) ? "active" : ""}`}
                  onClick={() => toggleSymptom(code)}
                >
                  {symptomLabel(t, code)}
                </button>
              ))}
            </div>
          </div>

          <div className="form-grid-2">
            <div className="field">
              <label className="field-label" htmlFor="affectedCount">
                {t("reportForm.affectedCountLabel")}
              </label>
              <input
                id="affectedCount"
                type="number"
                min="1"
                className="input"
                value={form.affectedCount}
                onChange={(e) => update("affectedCount", e.target.value)}
              />
            </div>

            <div className="field">
              <label className="field-label" htmlFor="reporterLanguage">
                {t("reportForm.languageLabel")}
              </label>
              <select
                id="reporterLanguage"
                className="select"
                value={form.reporterLanguage}
                onChange={(e) => update("reporterLanguage", e.target.value)}
              >
                {LANGUAGE_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="field">
            <label className="field-label" htmlFor="addressText">
              {t("reportForm.addressLabel")}
            </label>
            <input
              id="addressText"
              type="text"
              className="input"
              placeholder={t("reportForm.addressPlaceholder")}
              value={form.addressText}
              onChange={(e) => update("addressText", e.target.value)}
            />
            <div style={{ marginTop: 10 }}>
              <Button type="button" variant="secondary" size="sm" onClick={captureLocation}>
                {locationStatus === "locating" ? t("reportForm.locating") : t("reportForm.shareLocation")}
              </Button>
              {locationStatus === "captured" && (
                <span className="field-hint" style={{ marginLeft: 10, color: "#1f7a4d" }}>
                  {t("reportForm.locationCaptured")}
                </span>
              )}
              {locationStatus === "denied" && (
                <span className="field-hint" style={{ marginLeft: 10 }}>
                  {t("reportForm.locationDenied")}
                </span>
              )}
            </div>
          </div>

          <div className="field">
            <label className="field-label" htmlFor="attachments">
              {t("reportForm.attachmentsLabel")}
            </label>
            <input
              id="attachments"
              type="file"
              className="input"
              accept={ALLOWED_ATTACHMENT_TYPES.join(",")}
              multiple
              disabled={attachments.length >= MAX_ATTACHMENTS}
              onChange={handleFilePick}
            />
            <span className="field-hint">{t("reportForm.attachmentsHint")}</span>
            {attachments.length > 0 && (
              <ul style={{ listStyle: "none", padding: 0, marginTop: 10, display: "grid", gap: 6 }}>
                {attachments.map((file, index) => (
                  <li
                    key={`${file.name}-${index}`}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      fontSize: "0.85rem",
                      background: "var(--glass-fill)",
                      borderRadius: 10,
                      padding: "6px 10px",
                    }}
                  >
                    <span>{file.name}</span>
                    <button
                      type="button"
                      className="btn btn-ghost btn-sm"
                      onClick={() => removeAttachment(index)}
                    >
                      {t("reportForm.attachmentsRemove")}
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </GlassCard>

        <GlassCard style={{ position: "sticky", top: 110 }}>
          <h3 style={{ marginBottom: 6 }}>{t("reportForm.contactHeading")}</h3>
          <p style={{ color: "#5c6b85", fontSize: "0.88rem", marginBottom: 18 }}>
            {t("reportForm.contactSubheading")}
          </p>

          <div className="checkbox-row" style={{ marginBottom: 18 }}>
            <input
              id="isAnonymous"
              type="checkbox"
              checked={form.isAnonymous}
              onChange={(e) => update("isAnonymous", e.target.checked)}
            />
            <label htmlFor="isAnonymous" style={{ fontSize: "0.92rem" }}>
              {t("reportForm.anonymousLabel")}
            </label>
          </div>

          {!form.isAnonymous && (
            <div className="field">
              <label className="field-label" htmlFor="reporterContact">
                {t("reportForm.contactLabel")}
              </label>
              <input
                id="reporterContact"
                type="text"
                className="input"
                placeholder={t("reportForm.contactPlaceholder")}
                value={form.reporterContact}
                onChange={(e) => update("reporterContact", e.target.value)}
              />
            </div>
          )}

          <ErrorAlert message={error} />

          <Button type="submit" block loading={isSubmitting} style={{ marginTop: 8 }}>
            {t("reportForm.submitButton")}
          </Button>

          <p style={{ fontSize: "0.78rem", color: "#7c8aa5", marginTop: 14, textAlign: "center" }}>
            {t("reportForm.referenceHint")}
          </p>
        </GlassCard>
      </form>
    </div>
  );
}
