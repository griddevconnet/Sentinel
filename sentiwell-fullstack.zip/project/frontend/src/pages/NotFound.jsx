import { Link } from "react-router-dom";
import GlassCard from "../components/GlassCard";
import { useLanguage } from "../i18n/LanguageContext";

export default function NotFound() {
  const { t } = useLanguage();
  return (
    <div className="page-shell" style={{ maxWidth: 480, margin: "80px auto", textAlign: "center" }}>
      <GlassCard>
        <h2 style={{ marginBottom: 10 }}>{t("notFound.heading")}</h2>
        <p style={{ color: "#5c6b85", marginBottom: 20 }}>{t("notFound.body")}</p>
        <Link to="/" className="btn btn-primary">
          {t("notFound.homeButton")}
        </Link>
      </GlassCard>
    </div>
  );
}
