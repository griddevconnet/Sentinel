import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import GlassCard from "../components/GlassCard";
import Button from "../components/Button";
import { StatusBadge, PriorityBadge } from "../components/Badge";
import { ErrorAlert } from "../components/Feedback";
import { reportsApi } from "../api/reports";
import { ApiError } from "../api/client";
import { formatDateTime } from "../utils/formatters";
import { categoryLabel } from "../utils/constants";
import { useLanguage } from "../i18n/LanguageContext";

export default function TrackStatus() {
  const { t } = useLanguage();
  const [searchParams] = useSearchParams();
  const [token, setToken] = useState(searchParams.get("token") || "");
  const [report, setReport] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const lookup = async (value) => {
    if (!value || value.trim().length < 4) {
      setError(t("trackStatus.errorEmpty"));
      return;
    }
    setError("");
    setIsLoading(true);
    setReport(null);
    try {
      const res = await reportsApi.getByToken(value.trim().toUpperCase());
      setReport(res.data);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : t("trackStatus.errorNotFound"));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const initial = searchParams.get("token");
    if (initial) lookup(initial);
    // Runs once on mount to honor a pre-filled reference code.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    lookup(token);
  };

  return (
    <div className="page-shell" style={{ maxWidth: 640, margin: "0 auto" }}>
      <div className="page-header" style={{ padding: "44px 0 24px" }}>
        <div>
          <h1>{t("trackStatus.heading")}</h1>
          <p>{t("trackStatus.subheading")}</p>
        </div>
      </div>

      <GlassCard>
        <form onSubmit={handleSubmit} style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <input
            type="text"
            className="input"
            style={{ flex: 1, minWidth: 200, textTransform: "uppercase" }}
            placeholder={t("trackStatus.placeholder")}
            value={token}
            onChange={(e) => setToken(e.target.value)}
          />
          <Button type="submit" loading={isLoading}>
            {t("trackStatus.checkButton")}
          </Button>
        </form>
        <ErrorAlert message={error} />
      </GlassCard>

      {report && (
        <GlassCard style={{ marginTop: 22 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
            <div>
              <p style={{ fontSize: "0.8rem", color: "#7c8aa5", marginBottom: 4 }}>{t("trackStatus.referenceCode")}</p>
              <h3 style={{ fontFamily: "var(--font-display)", letterSpacing: "0.08em" }}>{report.report_token}</h3>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <StatusBadge status={report.status} />
              <PriorityBadge priority={report.priority_level} />
            </div>
          </div>

          <div style={{ marginTop: 24, display: "grid", gap: 14 }}>
            <DetailRow label={t("trackStatus.category")} value={categoryLabel(t, report.category)} />
            <DetailRow label={t("trackStatus.reported")} value={formatDateTime(report.created_at)} />
            {report.triaged_at && <DetailRow label={t("trackStatus.reviewed")} value={formatDateTime(report.triaged_at)} />}
            {report.resolved_at && <DetailRow label={t("trackStatus.resolvedAt")} value={formatDateTime(report.resolved_at)} />}
          </div>

          <div className="alert alert-info" style={{ marginTop: 22 }}>
            <span aria-hidden="true">{"\u2139"}</span>
            <span>
              {report.status === "resolved" || report.status === "closed"
                ? t("trackStatus.closedMessage")
                : t("trackStatus.openMessage")}
            </span>
          </div>
        </GlassCard>
      )}
    </div>
  );
}

function DetailRow({ label, value }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", gap: 12, fontSize: "0.92rem" }}>
      <span style={{ color: "#7c8aa5" }}>{label}</span>
      <span style={{ fontWeight: 600 }}>{value}</span>
    </div>
  );
}
