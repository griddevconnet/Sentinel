export function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;

  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch((err) => {
      // Offline support is a progressive enhancement — a registration failure
      // (e.g. unsupported browser, blocked by an extension) shouldn't break the app.
      // eslint-disable-next-line no-console
      console.warn("Service worker registration failed", err);
    });
  });
}
