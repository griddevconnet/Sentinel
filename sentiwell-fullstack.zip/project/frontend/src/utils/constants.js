export const PRIORITY_LABELS = {
  critical: "Critical",
  high: "High",
  medium: "Medium",
  low: "Low",
};

export const STATUS_LABELS = {
  submitted: "Submitted",
  triaged: "Triaged",
  assigned: "Assigned",
  in_progress: "In progress",
  escalated: "Escalated",
  resolved: "Resolved",
  closed: "Closed",
};

export const CATEGORY_LABELS = {
  individual_symptom: "Individual symptom",
  suspected_outbreak: "Suspected outbreak",
  environmental_hazard: "Environmental hazard",
  other: "Other concern",
};

export const CATEGORY_DESCRIPTIONS = {
  individual_symptom: "One person is feeling unwell",
  suspected_outbreak: "Several people nearby are showing similar symptoms",
  environmental_hazard: "Contaminated water, sewage exposure, or a chemical concern",
  other: "Something else the team should know about",
};

// Values only — display labels are translated via t(`symptom.${value}`), see i18n/translations.js.
export const SYMPTOM_CODES = [
  "fever",
  "high_fever",
  "cough",
  "difficulty_breathing",
  "diarrhea",
  "persistent_vomiting",
  "dehydration",
  "rash",
  "headache",
  "body_pain",
  "chest_pain",
  "seizure",
  "unconscious",
  "severe_bleeding",
  "snake_bite",
  "suspected_poisoning",
  "contaminated_water",
  "sewage_exposure",
  "chemical_exposure",
];

/** Given a translation function from useLanguage(), returns the label for a priority/status/category/symptom code. */
export function priorityLabel(t, value) {
  return t(`priority.${value}`) || value;
}
export function statusLabel(t, value) {
  return t(`status.${value}`) || value;
}
export function categoryLabel(t, value) {
  return t(`category.${value}`) || value;
}
export function categoryDescriptionText(t, value) {
  return t(`categoryDescription.${value}`) || "";
}
export function symptomLabel(t, value) {
  return t(`symptom.${value}`) || value.replace(/_/g, " ");
}

export const LANGUAGE_OPTIONS = [
  { value: "en", label: "English" },
  { value: "fr", label: "Français" },
];

export function priorityBadgeClass(priority) {
  return `badge badge-${priority || "neutral"}`;
}

export function statusBadgeClass(status) {
  const map = {
    submitted: "badge-neutral",
    triaged: "badge-medium",
    assigned: "badge-medium",
    in_progress: "badge-high",
    escalated: "badge-critical",
    resolved: "badge-low",
    closed: "badge-neutral",
  };
  return `badge ${map[status] || "badge-neutral"}`;
}
