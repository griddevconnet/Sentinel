# Sentiwell, Frontend

React (JavaScript, Vite) frontend for the Community Health Reporting and Triage application.
Plain CSS design system, no UI framework, blue and white glass theme throughout.

## Getting started

```bash
cp .env.example .env       # point VITE_API_BASE_URL at your running backend
npm install
npm run dev                # http://localhost:5173
```

The backend must be running (see the backend README) with `CORS_ORIGIN` set to
`http://localhost:5173` in its `.env` for local development.

## What is here

```
src/
  api/            fetch based client for every backend endpoint
  context/        AuthContext, holds the signed in health worker's session
  i18n/           LanguageContext (EN/FR) + translation dictionaries
  components/     GlassCard, Button, Badge, Navbar, OfflineBanner, loading and empty states
  pages/
    Landing            entry point with three clear paths
    ReportForm          public report submission
    TrackStatus          public, token based status lookup
    Login                health worker sign in
    TriageDashboard     the priority pulse bar and sorted queue
    ReportDetail         full report view, history, and triage actions
    Incidents             detected clusters
    IncidentDetail        cluster detail and status control
  routes/
    ProtectedRoute      redirects to sign in when a session is required
  index.css, components.css, layout.css, dashboard.css
                          the design system: tokens, components, layout, dashboard
```

## Design system

- Palette: deep signal blue (`#2f73f5`) through navy (`#0c1e3d`), on white and ice
  backgrounds, with a soft animated blue gradient behind every page.
- Surfaces are frosted glass: translucent white fills, blurred backdrops, soft
  blue tinted shadows, generous rounded corners.
- Type: Sora for headings and labels, Inter for body text.
- Signature element: the priority pulse bar on the triage dashboard, a live,
  glanceable read of how many open reports sit at each priority, with a soft
  pulsing glow on the critical count when it is above zero.
- Copy and interface labels are written without hyphens or dashes throughout.

## Offline support (PWA)

The app is installable and works offline:

- `public/sw.js` is a hand-written service worker (no Workbox/vite-plugin-pwa dependency)
  that caches the app shell on first visit, serves static assets stale-while-revalidate,
  and serves the last-seen response for backend `GET` calls when the network is down.
- `public/manifest.webmanifest` + `public/icons/` make the app installable to a home screen.
- Submitting the report form while offline (or when the request fails due to no
  connectivity) saves the report in `localStorage` via `src/utils/offlineQueue.js`
  instead of failing. `OfflineBanner` shows the offline/pending-sync state and
  automatically retries queued reports once the browser regains connectivity.

## Multilingual UI

`src/i18n/` provides a lightweight `LanguageProvider`/`useLanguage()` context (no external
i18n library) with English and French dictionaries covering navigation, the landing page,
report submission, status tracking, sign in, and all domain vocabulary (priority levels,
statuses, categories, symptoms). The language switcher lives in the navbar and persists to
`localStorage`. Full sentence-level copy is translated for every community-facing page
(Landing, Report a concern, Track a report, Sign in); the health-worker dashboard pages
currently translate domain vocabulary (via `Badge` and the `*Label` helpers in
`utils/constants.js`) but keep their own working copy in English.

## Connecting to the backend

Every request goes through `src/api/client.js`, which reads `VITE_API_BASE_URL`
and attaches the stored JWT to authenticated calls automatically. To point the
app at a different backend (staging, production), change that one environment
variable, no code changes needed.

Public flows (report submission, status tracking) call the API with no token.
Health worker flows (dashboard, report actions, incidents) require sign in;
`ProtectedRoute` handles the redirect, and `AuthContext` restores the session
from the stored token on page load.
