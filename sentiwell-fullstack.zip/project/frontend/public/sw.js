// Sentiwell service worker — no build-step dependency (no Workbox/vite-plugin-pwa),
// so it works with a plain `vite build` output. Bump CACHE_VERSION on any
// meaningful change to invalidate old caches on the next visit.
const CACHE_VERSION = "v1";
const CACHE_NAME = `sentiwell-cache-${CACHE_VERSION}`;
const API_CACHE_NAME = `sentiwell-api-cache-${CACHE_VERSION}`;

const APP_SHELL = [
  "/",
  "/index.html",
  "/manifest.webmanifest",
  "/offline.html",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key !== CACHE_NAME && key !== API_CACHE_NAME)
            .map((key) => caches.delete(key))
        )
      )
      .then(() => self.clients.claim())
  );
});

async function networkFirst(request, cacheName) {
  const cache = await caches.open(cacheName);
  try {
    const response = await fetch(request);
    if (response && response.ok) cache.put(request, response.clone());
    return response;
  } catch (err) {
    const cached = await cache.match(request);
    if (cached) return cached;
    throw err;
  }
}

async function staleWhileRevalidate(request) {
  const cache = await caches.open(CACHE_NAME);
  const cached = await cache.match(request);
  const networkPromise = fetch(request)
    .then((response) => {
      if (response && response.ok) cache.put(request, response.clone());
      return response;
    })
    .catch(() => undefined);
  return cached || networkPromise || fetch(request);
}

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return; // POST (report submission) is handled by the app's own offline queue.

  const url = new URL(request.url);

  // Backend API GET requests (triage queue, report status, incidents) — show the
  // last-seen data when offline rather than a hard failure.
  if (url.pathname.includes("/api/")) {
    event.respondWith(networkFirst(request, API_CACHE_NAME));
    return;
  }

  // Only handle same-origin app requests below (skip Google Fonts etc — let the browser do its own thing).
  if (url.origin !== self.location.origin) return;

  // Full-page navigations — try the network, fall back to the cached shell, then a friendly offline page.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((response) => {
          caches.open(CACHE_NAME).then((cache) => cache.put("/index.html", response.clone()));
          return response;
        })
        .catch(async () => (await caches.match("/index.html")) || caches.match("/offline.html"))
    );
    return;
  }

  // Static assets (JS/CSS/images) — serve from cache immediately, refresh in the background.
  event.respondWith(staleWhileRevalidate(request));
});
